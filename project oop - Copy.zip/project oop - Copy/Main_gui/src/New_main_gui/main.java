/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package New_main_gui;
import content.First;
import content.Fourth;
import content.Second;
import content.Third;
import java.awt.Color;
public class main extends javax.swing.JFrame {
    First f = new First();
    Second s = new Second();
    Third t = new Third();
    Fourth fo = new Fourth();
    public main() {
        setUndecorated(true);
        initComponents();
        setBackground(new Color(0,0,0,0)); 
        if (menu1 != null) {
            menu1.initMoving(this);
        }
        menu1.setMain(this);
        
        jLayeredPane1.add(f);
        jLayeredPane1.add(s);
        jLayeredPane1.add(t);
        jLayeredPane1.add(fo);
        
        f.setBounds(0, 0, jLayeredPane1.getWidth(), jLayeredPane1.getHeight());
        s.setBounds(0, 0, jLayeredPane1.getWidth(), jLayeredPane1.getHeight());
        t.setBounds(0, 0, jLayeredPane1.getWidth(), jLayeredPane1.getHeight());
        fo.setBounds(0, 0, jLayeredPane1.getWidth(), jLayeredPane1.getHeight());
        showPanel(f);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelBorder1 = new swing.PanelBorder();
        menu1 = new component.Menu();
        jLayeredPane1 = new javax.swing.JLayeredPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1045, Short.MAX_VALUE)
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 836, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addComponent(menu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLayeredPane1))
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLayeredPane1)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void showPanel(javax.swing.JPanel panel) {
        f.setVisible(false);
        s.setVisible(false);
        t.setVisible(false);
        fo.setVisible(false);
        panel.setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new main().setVisible(true);
        });
    }

    public First getF() {
        return f;
    }

    public void setF(First f) {
        this.f = f;
    }

    public Second getS() {
        return s;
    }

    public void setS(Second s) {
        this.s = s;
    }

    public Third getT() {
        return t;
    }

    public void setT(Third t) {
        this.t = t;
    }

    public Fourth getFo() {
        return fo;
    }

    public void setFo(Fourth fo) {
        this.fo = fo;
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLayeredPane jLayeredPane1;
    private component.Menu menu1;
    private swing.PanelBorder panelBorder1;
    // End of variables declaration//GEN-END:variables
}
