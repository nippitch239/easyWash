
public class Data {

    private String[] months = {
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };
    private MonthData[] totalPriceofMonth = new MonthData[12]; //store total price of each month

    public Data() {
        for (int i = 0; i < 12; i++) {
            totalPriceofMonth[i] = new MonthData();
        }

        setPrice(3, 350, 0);
        setPrice(2, 550, 0);
        setPrice(2, 550, 1);
        setPrice(2, 250, 1);
        setPrice(3, 450, 1);
        setPrice(9, 450, 0);
    }

    public void setPrice(int monthIndex, int price, int choice) { //choice 0 = income, 1 = expense
        if (monthIndex >= 0 & monthIndex <= 11) {
            if (choice == 0) {
                totalPriceofMonth[monthIndex].setIncome(price);
            } else if (choice == 1) {
                totalPriceofMonth[monthIndex].setExpense(price);
            }
        } else {
            throw new IllegalArgumentException("Month should be index between 0 - 11");
        }
    }

    public int getPrice(int monthIndex, int choice) {
        int price = 0;
        if (monthIndex >= 0 & monthIndex <= 11) {
            if (choice == 0) {
                price = totalPriceofMonth[monthIndex].getIncome();
            } else if (choice == 1) {
                price = totalPriceofMonth[monthIndex].getExpense();
            }
            return price;
        } else {
            throw new IllegalArgumentException("Month should be index between 0 - 11");
        }
    }

    public void printAllPriceOfEachMonth() {
        for (int i = 0; i < 12; i++) {
            System.out.println(months[i] + ": " + totalPriceofMonth[i].toString());
        }
    }

    public MonthData[] getData() {
        return totalPriceofMonth;
    }

}
