
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class Dashboard {

    private JFrame frame;
    private JButton resultButton, logButton, queueButton;
    private JLabel alreadyAccountLabel, allprofitlabel, allincomelable, allloselabel;
    private JPanel mainPanel, barchartPanel, linechartPanel, showAllBudgetPanel;

    private CardLayout card;

    private Data data;

    private int totalPriceLabel;
    private int totalIncomeLabel;
    private int totalLosePriceLabel;

    public Dashboard() {
        frame = new JFrame("Dashboard");
        frame.setLayout(new BorderLayout());
        resultButton = new JButton("Result");
        logButton = new JButton("Log");
        queueButton = new JButton("Queue");

//        --------------------------------------------------------------
        showAllBudgetPanel = new JPanel();

        JPanel totalProfitPanel = new JPanel();

        JLabel firstProfitLabel = new JLabel("Total Profit", JLabel.CENTER);

        allprofitlabel = new JLabel(totalPriceLabel + " ฿", JLabel.CENTER);
        allprofitlabel.setFont(new Font("Arial", Font.BOLD, 24));
        allprofitlabel.setForeground(new Color(19, 56, 92));
        setAllProfitLabel();

        totalProfitPanel.setLayout(new GridLayout(2, 1, 0, -50));
        totalProfitPanel.setPreferredSize(new Dimension(250, 100));
        totalProfitPanel.setBackground(new Color(255, 255, 255));

        totalProfitPanel.add(firstProfitLabel);
        totalProfitPanel.add(allprofitlabel);

//        -----------
        JPanel totalIncomePanel = new JPanel();

        JLabel secondIncomeLabel = new JLabel("Total Income", JLabel.CENTER);

        allincomelable = new JLabel(totalIncomeLabel + " ฿", JLabel.CENTER);
        allincomelable.setFont(new Font("Arial", Font.BOLD, 24));
        allincomelable.setForeground(new Color(61, 115, 34));

        totalIncomePanel.setLayout(new GridLayout(2, 1, 0, -50));
        totalIncomePanel.setPreferredSize(new Dimension(250, 100));
        totalIncomePanel.setBackground(new Color(255, 255, 255));

        totalIncomePanel.add(secondIncomeLabel);
        totalIncomePanel.add(allincomelable);
        setIncomeLabel();

//        -----------
        JPanel totalLosePanel = new JPanel();

        JLabel thirdLoseLabel = new JLabel("Total Lose", JLabel.CENTER);

        allloselabel = new JLabel(totalLosePriceLabel + " ฿", JLabel.CENTER);
        allloselabel.setFont(new Font("Arial", Font.BOLD, 24));
        allloselabel.setForeground(new Color(158, 37, 28));
        setAllLoseLabel();

        totalLosePanel.setLayout(new GridLayout(2, 1, 0, -50));
        totalLosePanel.setPreferredSize(new Dimension(250, 100));
        totalLosePanel.setBackground(new Color(255, 255, 255));

        totalLosePanel.add(thirdLoseLabel);
        totalLosePanel.add(allloselabel);

        showAllBudgetPanel.add(totalProfitPanel);
        showAllBudgetPanel.add(totalIncomePanel);
        showAllBudgetPanel.add(totalLosePanel);

//        --------------------------------------------------------------
        JPanel panelButton = new JPanel();
        panelButton.add(resultButton);
        panelButton.add(logButton);
        panelButton.add(queueButton);

        resultButton.addActionListener(new resultButtonHandler());
        logButton.addActionListener(new logButtonHandler());

        card = new CardLayout();
        mainPanel = new JPanel(card);

        barchartPanel = new JPanel();
        barchartPanel.setLayout(new BorderLayout());

        linechartPanel = new JPanel();
        linechartPanel.setLayout(new BorderLayout());

        mainPanel.add(barchartPanel, "Barchart");
        mainPanel.add(linechartPanel, "Linechart");

        frame.add(showAllBudgetPanel, BorderLayout.NORTH);
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(panelButton, BorderLayout.SOUTH);

        card.show(mainPanel, "Barchart");
        showBarChart();
        frame.setSize(1200, 850);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void showBarChart() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        data = new Data();
        data.setPrice(0, 100, 0);
//        data.printAllPriceOfEachMonth();

        String[] months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        };

        for (int i = 0; i < months.length; i++) {
            dataset.setValue(data.getPrice(i, 0), "Income", months[i]);
            dataset.setValue(data.getPrice(i, 1), "Expense", months[i]);
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Income and Expense", "Monthly", "Amount", dataset,
                PlotOrientation.VERTICAL, false, true, false
        );

        CategoryPlot categoryPlot = chart.getCategoryPlot();
        categoryPlot.setBackgroundPaint(Color.WHITE);

        BarRenderer renderer = (BarRenderer) categoryPlot.getRenderer();

        Color incomColor = new Color(107, 230, 255);
        Color expenseColor = new Color(34, 82, 92);

        renderer.setSeriesPaint(0, incomColor);
        renderer.setSeriesPaint(1, expenseColor);

        renderer.setMaximumBarWidth(0.01);
        renderer.setItemMargin(0.05);

        ChartPanel barChartPanel = new ChartPanel(chart);
        barchartPanel.removeAll();
        barchartPanel.add(barChartPanel, BorderLayout.CENTER);
        barchartPanel.validate();
    }

    public void showLineChart() { // test

        TimeSeries series = new TimeSeries("Frequency");

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        //----------------
            Date date1 = dateFormat.parse("2025-01-01");
            Date date2 = dateFormat.parse("2025-01-02");
            Date date3 = dateFormat.parse("2025-01-03");
            Date date4 = dateFormat.parse("2025-01-04");
            Date date5 = dateFormat.parse("2025-01-05");

            series.addOrUpdate(new org.jfree.data.time.Day(date1), 50);
            series.addOrUpdate(new org.jfree.data.time.Day(date2), 350);
            series.addOrUpdate(new org.jfree.data.time.Day(date3), 100);
            series.addOrUpdate(new org.jfree.data.time.Day(date4), 500);
            series.addOrUpdate(new org.jfree.data.time.Day(date5), 20);
        //----------------
        } catch (ParseException e) {
            System.out.println(e);
        }

        TimeSeriesCollection dataset = new TimeSeriesCollection(series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Frequency",
                "Time",
                "Number of Visits",
                dataset,
                false,
                true,
                false
        );

        XYPlot plot = chart.getXYPlot();

        plot.setBackgroundPaint(Color.WHITE);
        plot.setDomainGridlinePaint(Color.LIGHT_GRAY);
        plot.setRangeGridlinePaint(Color.LIGHT_GRAY);
        ChartPanel lineChartPanel = new ChartPanel(chart);

        lineChartPanel.removeAll();
        linechartPanel.add(lineChartPanel, BorderLayout.CENTER);
        linechartPanel.validate();

    }

    public class resultButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            card.show(mainPanel, "Barchart");
            showBarChart();
        }
    }

    public class logButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            card.show(mainPanel, "Linechart");
            showLineChart();
        }
    }
//
//    public class resultButtonHandler implements ActionListener {
//
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            card.show(mainPanel, "Barchart");
//        }
//    }

    public void setAllProfitLabel() {
        Data data = new Data();

        MonthData[] datas = data.getData();

        double price = 0;

        for (MonthData d : datas) {
            price += d.getTotal();
        }

        if (price >= 1000) {
            price /= 1000;
            System.out.println(price);
            allprofitlabel.setText(price + "K");
            return;
        }
        allprofitlabel.setText(price + "");
    }

    public void setAllLoseLabel() {

        Data data = new Data();

        MonthData[] datas = data.getData();

        double price = 0;

        for (MonthData d : datas) {
            price += d.getExpense();
        }
        System.out.println(price);

        if (price >= 1000) {
            price /= 1000;
            System.out.println(price);
            allloselabel.setText(price + "K");
            return;
        }
        allloselabel.setText(price + "");
    }

    public void setIncomeLabel() {
        Data data = new Data();

        MonthData[] datas = data.getData();

        double price = 0;
        for (MonthData d : datas) {
            price += d.getIncome();
        }

        if (price >= 1000) {
            price /= 1000;
            System.out.println(price);
            allincomelable.setText(price + "K");
            return;
        }
        allincomelable.setText(price + "");

    }

    public static void main(String[] args) {
        new Dashboard();
    }
}
