
public class MonthData { //data each month store income and expense

    private int income;
    private int expense;

    public MonthData() {
        this.income = 0;
        this.expense = 0;
    }

    public MonthData(int income, int expense) {
        this.income = income;
        this.expense = expense;
    }

    public int getIncome() {
        return income;
    }

    public void setIncome(int income) {
        this.income += income;
    }

    public int getExpense() {
        return expense;
    }

    public void setExpense(int expense) {
        this.expense += expense;
    }

    public int getTotal() {
        return income - expense;
    }

    @Override
    public String toString() {
        return "{" + "income= " + income + ", expense= " + expense + ", total= " + getTotal() + '}';
    }

}
